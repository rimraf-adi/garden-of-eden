Build: run  pdflatex main.tex  twice (second run fills the table of contents).
Needs a standard TeX Live install (tcolorbox, pgfplots, mathpazo, etc.).
main.tex is the entry point; part_a/b/c.tex pull in ch01-ch16.tex.
